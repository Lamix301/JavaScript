// const libros = [
//     { titulo: "El nombre de la rosa", autor: "Umberto Eco", leido: true },
//     { titulo: "El Señor de los Anillos", autor: "J.R.R. Tolkien", leido: false },
//     { titulo: "El Ingenioso Hidalgo Don Quixote de la Mancha", autor: "Miguel de Cervantes", leido: true },
//     { titulo: "El Camino", autor: "Miguel Delibes", leido: false },
// ];

// libros.forEach(libro => {
//     if (libro.leido) {
//         console.log(`Ya has leído "${libro.titulo}" de ${libro.autor}.`);
//     } else {
//         console.log(`No has leído "${libro.titulo}" de ${libro.autor}.`);
//     }
// });
